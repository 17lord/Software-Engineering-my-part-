INSERT INTO users VALUES (1, 'mkyong', 'mkyong@gmail.com');
INSERT INTO users VALUES (2, 'alex', 'alex@yahoo.com');
INSERT INTO users VALUES (3, 'joel', 'joel@gmail.com');

INSERT INTO students VALUES('lis@douglascollege.ca', 'Simon Li', '123456');
INSERT INTO students VALUES('wongi5@douglascollege.ca', 'Ivan Wong', '654321');

INSERT INTO courses VALUES('CSIS1175', 'Introduction to Programming 1');
INSERT INTO courses VALUES('CSIS1275', 'Introduction to Programming 2');

INSERT INTO registrations VALUES('wongi5@douglascollege.ca', 'CSIS1275');